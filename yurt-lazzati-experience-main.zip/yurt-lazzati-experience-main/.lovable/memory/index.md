Design: dark/light mode, gold (#D4A574) accents, Playfair Display + Nunito Sans fonts, glassmorphism cards
Language: 3-language support (UZ/RU/EN), contexts-based i18n
Pages: Home (=Menu), About (/haqimizda)
Brand: YURT LAZZATI — Uzbek + Uyghur cuisine restaurant
Layout: No navbar, centered logo header with lang selector + theme toggle
Categories: Birinchi ovqat, Ikkinchi ovqat, Uyg'ur taomlari, Salatlar, Pares taomlar
Features: Category filter, price sort, search, product detail modal
