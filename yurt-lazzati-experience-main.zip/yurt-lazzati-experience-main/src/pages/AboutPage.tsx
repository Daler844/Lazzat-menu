import { motion } from "framer-motion";
import { ArrowLeft, MapPin, Phone, Clock, Send } from "lucide-react";
import { Link } from "react-router-dom";
import { useLanguage } from "@/contexts/LanguageContext";

const AboutPage = () => {
  const { t } = useLanguage();

  return (
    <div className="pt-20 md:pt-24 pb-12 min-h-screen">
      <div className="container mx-auto px-4 max-w-3xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-sm font-body text-muted-foreground hover:text-foreground transition-colors mb-8"
          >
            <ArrowLeft size={16} />
            {t("backToMenu")}
          </Link>

          <h1 className="font-display text-3xl md:text-4xl font-bold gold-text mb-8">
            {t("aboutTitle")}
          </h1>

          <div className="space-y-6 mb-12">
            <p className="text-foreground/90 font-body leading-relaxed text-base">
              {t("aboutStory1")}
            </p>
            <p className="text-foreground/90 font-body leading-relaxed text-base">
              {t("aboutStory2")}
            </p>
          </div>

          <div className="glass-card rounded-xl p-6 mb-12">
            <h2 className="font-display text-xl font-bold text-primary mb-3">
              {t("ourMission")}
            </h2>
            <p className="text-muted-foreground font-body leading-relaxed">
              {t("missionText")}
            </p>
          </div>

          <h2 className="font-display text-xl font-bold text-foreground mb-6">
            {t("contact")}
          </h2>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="glass-card rounded-xl p-5 flex items-start gap-4">
              <MapPin size={20} className="text-primary shrink-0 mt-0.5" />
              <div>
                <p className="font-body text-sm text-muted-foreground mb-1">{t("address")}</p>
                <p className="font-body text-foreground text-sm">Toshkent shahar, Amir Temur ko'chasi 12</p>
              </div>
            </div>
            <div className="glass-card rounded-xl p-5 flex items-start gap-4">
              <Phone size={20} className="text-primary shrink-0 mt-0.5" />
              <div>
                <p className="font-body text-sm text-muted-foreground mb-1">{t("phone")}</p>
                <p className="font-body text-foreground text-sm">+998 90 123 45 67</p>
              </div>
            </div>
            <div className="glass-card rounded-xl p-5 flex items-start gap-4">
              <Clock size={20} className="text-primary shrink-0 mt-0.5" />
              <div>
                <p className="font-body text-sm text-muted-foreground mb-1">{t("workHours")}</p>
                <p className="font-body text-foreground text-sm">{t("workHoursValue")}</p>
              </div>
            </div>
            <a
              href="https://t.me/yurtlazzati"
              target="_blank"
              rel="noopener noreferrer"
              className="glass-card rounded-xl p-5 flex items-start gap-4 hover:border-primary/30 transition-colors"
            >
              <Send size={20} className="text-primary shrink-0 mt-0.5" />
              <div>
                <p className="font-body text-sm text-muted-foreground mb-1">Telegram</p>
                <p className="font-body text-foreground text-sm">@yurtlazzati</p>
              </div>
            </a>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default AboutPage;
