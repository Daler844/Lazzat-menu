import { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, SlidersHorizontal } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { menuItems, categories, type CategoryId, type MenuItem } from "@/data/menuData";
import ProductDetail from "@/components/ProductDetail";
import ReviewSection from "@/components/ReviewSection";

const Index = () => {
  const { lang, t } = useLanguage();
  const [activeCategory, setActiveCategory] = useState<CategoryId | "all">("all");
  const [selectedItem, setSelectedItem] = useState<MenuItem | null>(null);
  const [search, setSearch] = useState("");
  const [minPrice, setMinPrice] = useState(0);
  const [maxPrice, setMaxPrice] = useState(60000);
  const [showFilter, setShowFilter] = useState(false);

  const filteredItems = useMemo(() => {
    let items = activeCategory === "all"
      ? menuItems
      : menuItems.filter((item) => item.category === activeCategory);

    if (search.trim()) {
      const q = search.toLowerCase();
      items = items.filter(
        (item) =>
          item.name[lang].toLowerCase().includes(q) ||
          item.description[lang].toLowerCase().includes(q)
      );
    }

    items = items.filter((item) => item.price >= minPrice && item.price <= maxPrice);

    return items;
  }, [activeCategory, search, lang, minPrice, maxPrice]);

  return (
    <div className="pt-20 md:pt-24 pb-12 min-h-screen">
      <div className="container mx-auto px-4">
        {/* Subtitle */}
        <motion.p
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center text-muted-foreground font-body text-sm mb-6"
        >
          {t("subtitle")}
        </motion.p>

        {/* Search + Filter toggle */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 mb-4">
          <div className="relative flex-1">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={t("searchPlaceholder")}
              className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-card border border-border/40 text-foreground text-sm font-body placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/30 transition-all"
            />
          </div>
          <button
            onClick={() => setShowFilter(!showFilter)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl border border-border/40 text-sm font-body transition-all shrink-0 ${
              showFilter ? "bg-primary text-primary-foreground" : "bg-card text-muted-foreground hover:text-foreground"
            }`}
          >
            <SlidersHorizontal size={14} />
            <span>{t("priceRange")}</span>
          </button>
        </div>

        {/* Price range filter */}
        <AnimatePresence>
          {showFilter && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="overflow-hidden mb-4"
            >
              <div className="bg-card border border-border/30 rounded-xl p-4 flex flex-col sm:flex-row items-center gap-4">
                <div className="flex items-center gap-2 flex-1 w-full">
                  <label className="text-xs text-muted-foreground font-body whitespace-nowrap">{t("from")}:</label>
                  <input
                    type="number"
                    value={minPrice}
                    onChange={(e) => setMinPrice(Math.max(0, Number(e.target.value)))}
                    className="w-full px-3 py-2 rounded-lg bg-background border border-border/40 text-foreground text-sm font-body focus:outline-none focus:ring-2 focus:ring-primary/30"
                    min={0}
                    step={1000}
                  />
                </div>
                <div className="flex items-center gap-2 flex-1 w-full">
                  <label className="text-xs text-muted-foreground font-body whitespace-nowrap">{t("to")}:</label>
                  <input
                    type="number"
                    value={maxPrice}
                    onChange={(e) => setMaxPrice(Math.max(0, Number(e.target.value)))}
                    className="w-full px-3 py-2 rounded-lg bg-background border border-border/40 text-foreground text-sm font-body focus:outline-none focus:ring-2 focus:ring-primary/30"
                    min={0}
                    step={1000}
                  />
                </div>
                <span className="text-xs text-muted-foreground font-body">{t("currency")}</span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Category tabs */}
        <div className="flex flex-wrap gap-2 mb-8 overflow-x-auto pb-1">
          <button
            onClick={() => setActiveCategory("all")}
            className={`px-4 py-2 rounded-xl text-sm font-body font-medium transition-all duration-300 whitespace-nowrap ${
              activeCategory === "all"
                ? "bg-primary text-primary-foreground shadow-md"
                : "bg-card border border-border/40 text-muted-foreground hover:text-foreground"
            }`}
          >
            {t("allCategories")}
          </button>
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-4 py-2 rounded-xl text-sm font-body font-medium transition-all duration-300 whitespace-nowrap ${
                activeCategory === cat.id
                  ? "bg-primary text-primary-foreground shadow-md"
                  : "bg-card border border-border/40 text-muted-foreground hover:text-foreground"
              }`}
            >
              {cat.name[lang]}
            </button>
          ))}
        </div>

        {/* Menu grid */}
        <AnimatePresence mode="wait">
          <motion.div
            key={`${activeCategory}-${search}-${minPrice}-${maxPrice}`}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3 md:gap-4"
          >
            {filteredItems.map((item, i) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: Math.min(i * 0.03, 0.5), duration: 0.4 }}
                onClick={() => setSelectedItem(item)}
                className="group cursor-pointer bg-card border border-border/30 rounded-xl overflow-hidden hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5 transition-all duration-300"
              >
                <div className="relative aspect-square overflow-hidden bg-muted/10">
                  <img
                    src={item.image}
                    alt={item.name[lang]}
                    loading="lazy"
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                </div>
                <div className="p-3">
                  <h3 className="font-display text-sm font-semibold text-foreground truncate">
                    {item.name[lang]}
                  </h3>
                  <p className="font-body text-primary text-sm font-bold mt-1">
                    {item.price.toLocaleString()} <span className="text-xs font-normal text-muted-foreground">{t("currency")}</span>
                  </p>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </AnimatePresence>

        {filteredItems.length === 0 && (
          <p className="text-center text-muted-foreground py-12 font-body">
            {search ? "Hech narsa topilmadi" : "—"}
          </p>
        )}
      </div>

      {/* Reviews section */}
      <ReviewSection />

      <ProductDetail item={selectedItem} onClose={() => setSelectedItem(null)} />
    </div>
  );
};

export default Index;
