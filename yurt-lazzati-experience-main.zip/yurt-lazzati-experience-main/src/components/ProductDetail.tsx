import { motion, AnimatePresence } from "framer-motion";
import { X } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import type { MenuItem } from "@/data/menuData";

interface ProductDetailProps {
  item: MenuItem | null;
  onClose: () => void;
}

const ProductDetail = ({ item, onClose }: ProductDetailProps) => {
  const { lang, t } = useLanguage();

  return (
    <AnimatePresence>
      {item && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-md"
          onClick={onClose}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 30 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 30 }}
            transition={{ type: "spring", duration: 0.5 }}
            className="relative w-full max-w-lg bg-card border border-border/40 rounded-2xl overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={onClose}
              className="absolute top-4 right-4 z-10 p-2 rounded-full bg-background/60 backdrop-blur-sm text-foreground/70 hover:text-foreground transition-colors"
            >
              <X size={20} />
            </button>

            <div className="relative h-64 sm:h-72 bg-muted/20 overflow-hidden">
              <img
                src={item.image}
                alt={item.name[lang]}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent" />
            </div>

            <div className="p-6 -mt-8 relative">
              <h2 className="font-display text-2xl font-bold text-foreground mb-2">
                {item.name[lang]}
              </h2>
              <p className="text-muted-foreground text-sm leading-relaxed mb-4">
                {item.description[lang]}
              </p>
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs text-muted-foreground/60 uppercase tracking-wider">{t("price")}</span>
                  <p className="font-display text-2xl font-bold text-primary">
                    {item.price.toLocaleString()} <span className="text-sm font-body text-muted-foreground">{t("currency")}</span>
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default ProductDetail;
