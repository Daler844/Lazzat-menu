import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Star, Send } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";

interface Review {
  id: number;
  name: string;
  rating: number;
  comment: string;
  date: string;
}

const initialReviews: Review[] = [
  { id: 1, name: "Alisher", rating: 5, comment: "Juda mazali taomlar! Oilam bilan doim kelamiz.", date: "2026-03-20" },
  { id: 2, name: "Dilnoza", rating: 4, comment: "Lag'mon va manti zo'r! Xizmat ham a'lo.", date: "2026-03-18" },
  { id: 3, name: "Rustam", rating: 5, comment: "Eng yaxshi o'zbek oshxonasi. Osh sofi ajoyib!", date: "2026-03-15" },
];

const ReviewSection = () => {
  const { t } = useLanguage();
  const [reviews, setReviews] = useState<Review[]>(initialReviews);
  const [name, setName] = useState("");
  const [comment, setComment] = useState("");
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !comment.trim() || rating === 0) return;

    const newReview: Review = {
      id: Date.now(),
      name: name.trim(),
      rating,
      comment: comment.trim(),
      date: new Date().toISOString().split("T")[0],
    };

    setReviews((prev) => [newReview, ...prev]);
    setName("");
    setComment("");
    setRating(0);
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 3000);
  };

  const avgRating = reviews.length
    ? (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1)
    : "0";

  return (
    <section className="mt-12 mb-8">
      <div className="container mx-auto px-4">
        <h2 className="font-display text-2xl font-bold text-foreground mb-2">
          {t("reviews")}
        </h2>
        <div className="flex items-center gap-2 mb-6">
          <div className="flex">
            {[1, 2, 3, 4, 5].map((s) => (
              <Star
                key={s}
                size={18}
                className={`${Number(avgRating) >= s ? "text-primary fill-primary" : "text-muted-foreground/30"}`}
              />
            ))}
          </div>
          <span className="text-sm font-body text-muted-foreground">
            {avgRating} ({reviews.length})
          </span>
        </div>

        {/* Review form */}
        <form onSubmit={handleSubmit} className="bg-card border border-border/30 rounded-xl p-4 mb-6">
          <h3 className="font-display text-lg font-semibold text-foreground mb-3">
            {t("writeReview")}
          </h3>
          
          {/* Star rating input */}
          <div className="flex gap-1 mb-3">
            {[1, 2, 3, 4, 5].map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setRating(s)}
                onMouseEnter={() => setHoverRating(s)}
                onMouseLeave={() => setHoverRating(0)}
                className="p-0.5 transition-transform hover:scale-110"
              >
                <Star
                  size={24}
                  className={`transition-colors ${
                    (hoverRating || rating) >= s
                      ? "text-primary fill-primary"
                      : "text-muted-foreground/30"
                  }`}
                />
              </button>
            ))}
          </div>

          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder={t("yourName")}
            className="w-full px-3 py-2 rounded-lg bg-background border border-border/40 text-foreground text-sm font-body placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/30 mb-3"
          />
          <textarea
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            placeholder={t("yourReview")}
            rows={3}
            className="w-full px-3 py-2 rounded-lg bg-background border border-border/40 text-foreground text-sm font-body placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/30 mb-3 resize-none"
          />
          <button
            type="submit"
            disabled={!name.trim() || !comment.trim() || rating === 0}
            className="flex items-center gap-2 px-5 py-2 rounded-lg bg-primary text-primary-foreground font-body text-sm font-semibold hover:opacity-90 transition-opacity disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <Send size={14} />
            {t("submit")}
          </button>

          <AnimatePresence>
            {submitted && (
              <motion.p
                initial={{ opacity: 0, y: -5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="mt-3 text-sm text-primary font-body font-medium"
              >
                {t("thankYou")}
              </motion.p>
            )}
          </AnimatePresence>
        </form>

        {/* Reviews list */}
        <div className="space-y-3">
          {reviews.map((review, i) => (
            <motion.div
              key={review.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="bg-card border border-border/30 rounded-xl p-4"
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                    <span className="text-sm font-bold text-primary">{review.name[0]}</span>
                  </div>
                  <span className="font-body text-sm font-semibold text-foreground">{review.name}</span>
                </div>
                <span className="text-xs text-muted-foreground font-body">{review.date}</span>
              </div>
              <div className="flex gap-0.5 mb-2">
                {[1, 2, 3, 4, 5].map((s) => (
                  <Star
                    key={s}
                    size={14}
                    className={review.rating >= s ? "text-primary fill-primary" : "text-muted-foreground/30"}
                  />
                ))}
              </div>
              <p className="text-sm text-muted-foreground font-body leading-relaxed">{review.comment}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ReviewSection;
