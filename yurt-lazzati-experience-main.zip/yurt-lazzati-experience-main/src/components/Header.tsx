import { Link, useLocation } from "react-router-dom";
import { Moon, Sun, Info } from "lucide-react";
import { useLanguage, Language } from "@/contexts/LanguageContext";
import { useTheme } from "@/contexts/ThemeContext";

const langs: { id: Language; label: string }[] = [
  { id: "uz", label: "UZ" },
  { id: "ru", label: "RU" },
  { id: "en", label: "EN" },
];

const Header = () => {
  const { lang, setLang, t } = useLanguage();
  const { theme, toggleTheme } = useTheme();
  const location = useLocation();

  return (
    <header className="fixed top-0 left-0 right-0 z-40 bg-background/80 backdrop-blur-xl border-b border-border/30">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Language selector */}
          <div className="flex items-center gap-1">
            {langs.map((l) => (
              <button
                key={l.id}
                onClick={() => setLang(l.id)}
                className={`px-2.5 py-1.5 rounded-md text-xs font-body font-semibold tracking-wide transition-all duration-300 ${
                  lang === l.id
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {l.label}
              </button>
            ))}
          </div>

          {/* Logo */}
          <Link to="/" className="absolute left-1/2 -translate-x-1/2">
            <h1 className="font-display text-xl md:text-2xl font-bold gold-text tracking-wider whitespace-nowrap">
              YURT LAZZATI
            </h1>
          </Link>

          {/* Right controls */}
          <div className="flex items-center gap-2 md:gap-3">
            <button
              onClick={toggleTheme}
              className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-all duration-300"
              title={theme === "dark" ? t("lightMode") : t("darkMode")}
            >
              {theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}
            </button>
            <Link
              to={location.pathname === "/haqimizda" ? "/" : "/haqimizda"}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-body font-medium text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-all duration-300"
            >
              <Info size={16} />
              <span className="hidden sm:inline">{t("aboutUs")}</span>
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
