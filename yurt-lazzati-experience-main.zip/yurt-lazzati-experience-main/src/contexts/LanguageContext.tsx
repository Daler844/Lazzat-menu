import { createContext, useContext, useState, ReactNode, useCallback } from "react";

export type Language = "uz" | "ru" | "en";

interface LanguageContextType {
  lang: Language;
  setLang: (lang: Language) => void;
  t: (key: string) => string;
}

const translations: Record<string, Record<Language, string>> = {
  menu: { uz: "Menyu", ru: "Меню", en: "Menu" },
  aboutUs: { uz: "Biz haqimizda", ru: "О нас", en: "About Us" },
  allCategories: { uz: "Barchasi", ru: "Все", en: "All" },
  firstCourses: { uz: "Birinchi ovqat", ru: "Первые блюда", en: "First Courses" },
  secondCourses: { uz: "Ikkinchi ovqat", ru: "Вторые блюда", en: "Main Courses" },
  uyghurDishes: { uz: "Uyg'ur taomlari", ru: "Уйгурские блюда", en: "Uyghur Dishes" },
  salads: { uz: "Salatlar", ru: "Салаты", en: "Salads" },
  sideDishes: { uz: "Pares taomlar", ru: "Гарниры", en: "Side Dishes" },
  price: { uz: "Narxi", ru: "Цена", en: "Price" },
  currency: { uz: "so'm", ru: "сум", en: "UZS" },
  sortByPrice: { uz: "Narxi bo'yicha", ru: "По цене", en: "Sort by price" },
  lowToHigh: { uz: "Arzondan qimmatga", ru: "По возрастанию", en: "Low to High" },
  highToLow: { uz: "Qimmatdan arzonga", ru: "По убыванию", en: "High to Low" },
  defaultSort: { uz: "Standart", ru: "По умолчанию", en: "Default" },
  close: { uz: "Yopish", ru: "Закрыть", en: "Close" },
  lightMode: { uz: "Kunduzgi rejim", ru: "Светлая тема", en: "Light Mode" },
  darkMode: { uz: "Tungi rejim", ru: "Тёмная тема", en: "Dark Mode" },
  subtitle: { uz: "Milliy va Uyg'ur taomlari maskani", ru: "Дом национальной и уйгурской кухни", en: "Home of National & Uyghur Cuisine" },
  aboutTitle: { uz: "Biz haqimizda", ru: "О нас", en: "About Us" },
  aboutStory1: { uz: "YURT LAZZATI — bu faqat restoran emas, bu oila, an'ana va mehr maskani. Biz o'zbek va uyg'ur oshxonasining eng yaxshi an'analarini bir joyga jamlagan holda, har bir mehmonimizga uy qulayligi va mazali taomlar taqdim etamiz.", ru: "YURT LAZZATI — это не просто ресторан, это дом семьи, традиций и заботы. Мы объединяем лучшие традиции узбекской и уйгурской кухни, предлагая каждому гостю домашний уют и вкусные блюда.", en: "YURT LAZZATI is not just a restaurant — it is a home of family, tradition, and warmth. We bring together the finest traditions of Uzbek and Uyghur cuisine, offering every guest the comfort of home and delicious food." },
  aboutStory2: { uz: "Bizning oshpazlarimiz har bir taomni sevgi va mahorat bilan tayyorlaydi. Faqat tabiiy va sifatli mahsulotlar ishlatiladi. Sizni kutayapmiz!", ru: "Наши повара готовят каждое блюдо с любовью и мастерством. Используются только натуральные и качественные продукты. Ждём вас!", en: "Our chefs prepare every dish with love and craftsmanship. Only natural, quality ingredients are used. We look forward to welcoming you!" },
  ourMission: { uz: "Bizning maqsadimiz", ru: "Наша миссия", en: "Our Mission" },
  missionText: { uz: "An'anaviy ta'mlarni zamonaviy uslubda taqdim etish va har bir mehmon uchun unutilmas tajriba yaratish.", ru: "Представлять традиционные вкусы в современном стиле и создавать незабываемые впечатления для каждого гостя.", en: "To present traditional flavors in a modern style and create an unforgettable experience for every guest." },
  contact: { uz: "Bog'lanish", ru: "Контакты", en: "Contact" },
  address: { uz: "Manzil", ru: "Адрес", en: "Address" },
  phone: { uz: "Telefon", ru: "Телефон", en: "Phone" },
  workHours: { uz: "Ish vaqti", ru: "Время работы", en: "Working Hours" },
  workHoursValue: { uz: "Har kuni 10:00 - 23:00", ru: "Ежедневно 10:00 - 23:00", en: "Daily 10:00 AM - 11:00 PM" },
  backToMenu: { uz: "Menyuga qaytish", ru: "Вернуться в меню", en: "Back to Menu" },
  productDetails: { uz: "Taom haqida", ru: "О блюде", en: "Dish Details" },
  searchPlaceholder: { uz: "Taom qidirish...", ru: "Поиск блюда...", en: "Search dishes..." },
  priceRange: { uz: "Narx oralig'i", ru: "Диапазон цен", en: "Price Range" },
  from: { uz: "dan", ru: "от", en: "from" },
  to: { uz: "gacha", ru: "до", en: "to" },
  reviews: { uz: "Fikr-mulohazalar", ru: "Отзывы", en: "Reviews" },
  writeReview: { uz: "Fikr qoldirish", ru: "Оставить отзыв", en: "Write a Review" },
  yourName: { uz: "Ismingiz", ru: "Ваше имя", en: "Your Name" },
  yourReview: { uz: "Fikringiz", ru: "Ваш отзыв", en: "Your Review" },
  submit: { uz: "Yuborish", ru: "Отправить", en: "Submit" },
  thankYou: { uz: "Fikringiz uchun rahmat!", ru: "Спасибо за отзыв!", en: "Thank you for your review!" },
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider = ({ children }: { children: ReactNode }) => {
  const [lang, setLang] = useState<Language>("uz");

  const t = useCallback(
    (key: string) => translations[key]?.[lang] || key,
    [lang]
  );

  return (
    <LanguageContext.Provider value={{ lang, setLang, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) throw new Error("useLanguage must be used within LanguageProvider");
  return context;
};
