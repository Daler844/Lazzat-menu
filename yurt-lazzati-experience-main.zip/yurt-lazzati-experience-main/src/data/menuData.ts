import type { Language } from "@/contexts/LanguageContext";

import shurvaImg from "@/assets/shurva.jpg";
import mantiImg from "@/assets/manti.jpg";
import kawapImg from "@/assets/kawap.jpg";
import lagmanImg from "@/assets/lagman.jpg";
import plovImg from "@/assets/plov.jpg";
import daapanjiImg from "@/assets/dapanji.jpg";
import kotletImg from "@/assets/kotlet.jpg";
import stewImg from "@/assets/stew.jpg";
import golubtsynImg from "@/assets/golubtsy.jpg";
import steakImg from "@/assets/steak.jpg";
import shashlikImg from "@/assets/shashlik.jpg";
import saladImg from "@/assets/salad.jpg";
import olivyeImg from "@/assets/olivye.jpg";
import friesImg from "@/assets/fries.jpg";
import fishImg from "@/assets/fish.jpg";
import jizImg from "@/assets/jiz.jpg";
import riceImg from "@/assets/rice.jpg";
import pelmeniImg from "@/assets/pelmeni.jpg";

export type CategoryId = "birinchi" | "ikkinchi" | "uyghur" | "salat" | "garnir";

export interface MenuItem {
  id: string;
  name: Record<Language, string>;
  description: Record<Language, string>;
  price: number;
  image: string;
  category: CategoryId;
}

export interface Category {
  id: CategoryId;
  name: Record<Language, string>;
}

export const categories: Category[] = [
  { id: "birinchi", name: { uz: "Birinchi ovqat", ru: "Первые блюда", en: "First Courses" } },
  { id: "ikkinchi", name: { uz: "Ikkinchi ovqat", ru: "Вторые блюда", en: "Main Courses" } },
  { id: "uyghur", name: { uz: "Uyg'ur taomlari", ru: "Уйгурские блюда", en: "Uyghur Dishes" } },
  { id: "salat", name: { uz: "Salatlar", ru: "Салаты", en: "Salads" } },
  { id: "garnir", name: { uz: "Pares taomlar", ru: "Гарниры", en: "Side Dishes" } },
];

export const menuItems: MenuItem[] = [
  // === BIRINCHI OVQAT ===
  {
    id: "b1", category: "birinchi",
    name: { uz: "Gelak sho'rva", ru: "Суп с лапшой", en: "Vermicelli Soup" },
    description: { uz: "Yengil va mazali gelak sho'rva, go'sht va sabzavotlar bilan", ru: "Лёгкий и вкусный суп с лапшой, мясом и овощами", en: "Light and tasty vermicelli soup with meat and vegetables" },
    price: 28000, image: shurvaImg,
  },
  {
    id: "b2", category: "birinchi",
    name: { uz: "Bahor sho'rva", ru: "Весенний суп", en: "Spring Soup" },
    description: { uz: "Bahorgi yangi sabzavotlar bilan tayyorlangan sho'rva", ru: "Суп из свежих весенних овощей", en: "Soup made with fresh spring vegetables" },
    price: 25000, image: shurvaImg,
  },
  {
    id: "b3", category: "birinchi",
    name: { uz: "Sho'rva (mol go'sht)", ru: "Шурпа (говядина)", en: "Shorva (Beef)" },
    description: { uz: "An'anaviy mol go'shtli sho'rva", ru: "Традиционная шурпа из говядины", en: "Traditional beef soup" },
    price: 32000, image: shurvaImg,
  },
  {
    id: "b4", category: "birinchi",
    name: { uz: "Sho'rva (qo'y go'sht)", ru: "Шурпа (баранина)", en: "Shorva (Lamb)" },
    description: { uz: "An'anaviy qo'y go'shtli sho'rva", ru: "Традиционная шурпа из баранины", en: "Traditional lamb soup" },
    price: 35000, image: shurvaImg,
  },
  {
    id: "b5", category: "birinchi",
    name: { uz: "Mastava", ru: "Мастава", en: "Mastava" },
    description: { uz: "Guruch, sabzavot va go'shtli an'anaviy sho'rva", ru: "Традиционный суп с рисом, овощами и мясом", en: "Traditional soup with rice, vegetables and meat" },
    price: 30000, image: shurvaImg,
  },
  {
    id: "b6", category: "birinchi",
    name: { uz: "Ugra oshi", ru: "Угра оши", en: "Ugra Oshi" },
    description: { uz: "Qo'lda tayyorlangan ugrali sho'rva", ru: "Суп с домашней лапшой", en: "Homemade noodle soup" },
    price: 28000, image: shurvaImg,
  },
  {
    id: "b7", category: "birinchi",
    name: { uz: "Pelmeni", ru: "Пельмени", en: "Pelmeni" },
    description: { uz: "Go'shtli pelmeni, smetana bilan", ru: "Мясные пельмени со сметаной", en: "Meat pelmeni with sour cream" },
    price: 30000, image: pelmeniImg,
  },
  {
    id: "b8", category: "birinchi",
    name: { uz: "Pelmeni s bul'onom", ru: "Пельмени с бульоном", en: "Pelmeni in Broth" },
    description: { uz: "Issiq bul'onda pelmeni", ru: "Пельмени в горячем бульоне", en: "Pelmeni served in hot broth" },
    price: 32000, image: pelmeniImg,
  },

  // === IKKINCHI OVQAT ===
  {
    id: "i1", category: "ikkinchi",
    name: { uz: "Manti", ru: "Манты", en: "Manti" },
    description: { uz: "Bug'da pishirilgan yupqa xamirda go'shtli manti", ru: "Манты на пару с мясом в тонком тесте", en: "Steamed dumplings with meat in thin dough" },
    price: 35000, image: mantiImg,
  },
  {
    id: "i2", category: "ikkinchi",
    name: { uz: "Qozon kabob", ru: "Казан кабоб", en: "Kazan Kebab" },
    description: { uz: "Qozonda tayyorlangan go'shtli kabob", ru: "Кабоб, приготовленный в казане", en: "Kebab cooked in a kazan" },
    price: 48000, image: kawapImg,
  },
  {
    id: "i3", category: "ikkinchi",
    name: { uz: "Brizol", ru: "Бризоль", en: "Brizol" },
    description: { uz: "Tuxum qatlamida go'shtli brizol", ru: "Бризоль — мясо в яичной обёртке", en: "Meat wrapped in egg batter" },
    price: 38000, image: kotletImg,
  },
  {
    id: "i4", category: "ikkinchi",
    name: { uz: "Kotlet po-kiyevski", ru: "Котлета по-киевски", en: "Kiev Cutlet" },
    description: { uz: "Ichiga sariyog' solingan kotlet", ru: "Котлета с маслом внутри", en: "Cutlet stuffed with butter" },
    price: 42000, image: kotletImg,
  },
  {
    id: "i5", category: "ikkinchi",
    name: { uz: "Jarkoye", ru: "Жаркое", en: "Zharkoye" },
    description: { uz: "Go'sht va kartoshkali dimlanma", ru: "Тушёное мясо с картофелем", en: "Stewed meat with potatoes" },
    price: 40000, image: stewImg,
  },
  {
    id: "i6", category: "ikkinchi",
    name: { uz: "Go'lupsi", ru: "Голубцы", en: "Golubtsy" },
    description: { uz: "Go'shtli karam o'ramalari", ru: "Голубцы с мясной начинкой", en: "Cabbage rolls stuffed with meat" },
    price: 35000, image: golubtsynImg,
  },
  {
    id: "i7", category: "ikkinchi",
    name: { uz: "Osh sofi", ru: "Ош софи", en: "Osh Sofi" },
    description: { uz: "An'anaviy o'zbek oshi", ru: "Традиционный узбекский плов", en: "Traditional Uzbek pilaf" },
    price: 45000, image: plovImg,
  },
  {
    id: "i8", category: "ikkinchi",
    name: { uz: "Xorazm baliq", ru: "Хорезмская рыба", en: "Khorezm Fish" },
    description: { uz: "Xorazm uslubida tayyorlangan baliq", ru: "Рыба по-хорезмски", en: "Fish prepared Khorezm style" },
    price: 50000, image: fishImg,
  },
  {
    id: "i9", category: "ikkinchi",
    name: { uz: "Bifshteks", ru: "Бифштекс", en: "Beefsteak" },
    description: { uz: "Panjara ustida pishirilgan bifshteks", ru: "Бифштекс на гриле", en: "Grilled beefsteak" },
    price: 55000, image: steakImg,
  },
  {
    id: "i10", category: "ikkinchi",
    name: { uz: "Gulyash", ru: "Гуляш", en: "Goulash" },
    description: { uz: "Sous bilan tayyorlangan go'shtli gulyash", ru: "Мясной гуляш в соусе", en: "Meat goulash in sauce" },
    price: 38000, image: stewImg,
  },
  {
    id: "i11", category: "ikkinchi",
    name: { uz: "Qurtoba", ru: "Куртоба", en: "Qurtoba" },
    description: { uz: "An'anaviy qurtobali taom", ru: "Традиционное блюдо куртоба", en: "Traditional qurtoba dish" },
    price: 30000, image: stewImg,
  },
  {
    id: "i12", category: "ikkinchi",
    name: { uz: "Qurtob s myasom", ru: "Куртоб с мясом", en: "Qurtob with Meat" },
    description: { uz: "Go'shtli qurtob", ru: "Куртоб с мясом", en: "Qurtob served with meat" },
    price: 38000, image: stewImg,
  },
  {
    id: "i13", category: "ikkinchi",
    name: { uz: "Shashlik Napoleon", ru: "Шашлык Наполеон", en: "Napoleon Shashlik" },
    description: { uz: "Napolion uslubida tayyorlangan shashlik", ru: "Шашлык в стиле Наполеон", en: "Napoleon-style shashlik" },
    price: 45000, image: shashlikImg,
  },
  {
    id: "i14", category: "ikkinchi",
    name: { uz: "Shashlik Rulet", ru: "Шашлык Рулет", en: "Shashlik Roll" },
    description: { uz: "Rulet shaklida tayyorlangan shashlik", ru: "Шашлык в виде рулета", en: "Shashlik prepared as a roll" },
    price: 48000, image: shashlikImg,
  },
  {
    id: "i15", category: "ikkinchi",
    name: { uz: "Shashlik Karega", ru: "Шашлык Карега", en: "Shashlik Karega" },
    description: { uz: "Karega uslubida pishirilgan shashlik", ru: "Шашлык Карега", en: "Karega-style shashlik" },
    price: 45000, image: shashlikImg,
  },
  {
    id: "i16", category: "ikkinchi",
    name: { uz: "Shashlik Nejniy", ru: "Шашлык Нежный", en: "Tender Shashlik" },
    description: { uz: "Yumshoq va nozik shashlik", ru: "Нежный шашлык", en: "Soft and tender shashlik" },
    price: 45000, image: shashlikImg,
  },
  {
    id: "i17", category: "ikkinchi",
    name: { uz: "Pomidor s mangal", ru: "Помидоры на мангале", en: "Grilled Tomatoes" },
    description: { uz: "Mangalda pishirilgan pomidorlar", ru: "Помидоры, приготовленные на мангале", en: "Tomatoes grilled on charcoal" },
    price: 15000, image: shashlikImg,
  },
  {
    id: "i18", category: "ikkinchi",
    name: { uz: "Qo'ziqorin s mangal", ru: "Грибы на мангале", en: "Grilled Mushrooms" },
    description: { uz: "Mangalda pishirilgan qo'ziqorinlar", ru: "Грибы на мангале", en: "Mushrooms grilled on charcoal" },
    price: 20000, image: shashlikImg,
  },
  {
    id: "i19", category: "ikkinchi",
    name: { uz: "Sabzavotlar s mangal", ru: "Овощи на мангале", en: "Grilled Vegetables" },
    description: { uz: "Mangalda pishirilgan sabzavotlar", ru: "Овощи на мангале", en: "Vegetables grilled on charcoal" },
    price: 18000, image: shashlikImg,
  },
  {
    id: "i20", category: "ikkinchi",
    name: { uz: "Ragu s baraninoy", ru: "Рагу с бараниной", en: "Lamb Ragout" },
    description: { uz: "Qo'y go'shtli ragu", ru: "Рагу из баранины", en: "Lamb ragout" },
    price: 48000, image: stewImg,
  },
  {
    id: "i21", category: "ikkinchi",
    name: { uz: "Go'sht po-kitayski", ru: "Мясо по-китайски", en: "Chinese-style Meat" },
    description: { uz: "Xitoy uslubida tayyorlangan go'sht", ru: "Мясо по-китайски", en: "Chinese-style prepared meat" },
    price: 42000, image: jizImg,
  },
  {
    id: "i22", category: "ikkinchi",
    name: { uz: "Pechenka", ru: "Печёнка", en: "Liver" },
    description: { uz: "Piyoz bilan qovurilgan jigar", ru: "Печёнка, жареная с луком", en: "Fried liver with onions" },
    price: 35000, image: jizImg,
  },
  {
    id: "i23", category: "ikkinchi",
    name: { uz: "Jiz-jiz", ru: "Жиз-жиз", en: "Jiz-Jiz" },
    description: { uz: "An'anaviy o'zbek jiz-jizi", ru: "Традиционный узбекский жиз-жиз", en: "Traditional Uzbek jiz-jiz" },
    price: 40000, image: jizImg,
  },
  {
    id: "i24", category: "ikkinchi",
    name: { uz: "Lyaz-jiz", ru: "Ляз-жиз", en: "Lyaz-Jiz" },
    description: { uz: "Maxsus tayyorlangan lyaz-jiz", ru: "Ляз-жиз особого приготовления", en: "Specially prepared lyaz-jiz" },
    price: 42000, image: jizImg,
  },

  // === UYGHUR TAOMLARI ===
  {
    id: "u1", category: "uyghur",
    name: { uz: "Lag'mon suyuq", ru: "Лагман жидкий", en: "Liquid Lagman" },
    description: { uz: "Suyuq lag'mon, qo'lda cho'zilgan noodl bilan", ru: "Жидкий лагман с ручной лапшой", en: "Liquid lagman with hand-pulled noodles" },
    price: 35000, image: lagmanImg,
  },
  {
    id: "u2", category: "uyghur",
    name: { uz: "Lag'mon qovurilgan", ru: "Лагман жареный", en: "Fried Lagman" },
    description: { uz: "Qovurilgan lag'mon, go'sht va sabzavotlar bilan", ru: "Жареный лагман с мясом и овощами", en: "Fried lagman with meat and vegetables" },
    price: 38000, image: lagmanImg,
  },
  {
    id: "u3", category: "uyghur",
    name: { uz: "Say", ru: "Сай", en: "Sai" },
    description: { uz: "Uyg'ur an'anaviy say taomi", ru: "Уйгурское традиционное блюдо сай", en: "Traditional Uyghur sai dish" },
    price: 40000, image: daapanjiImg,
  },
  {
    id: "u4", category: "uyghur",
    name: { uz: "Say govyadina", ru: "Сай с говядиной", en: "Sai with Beef" },
    description: { uz: "Mol go'shtli say", ru: "Сай с говядиной", en: "Sai with beef" },
    price: 45000, image: daapanjiImg,
  },
  {
    id: "u5", category: "uyghur",
    name: { uz: "Say kuriniy", ru: "Сай с курицей", en: "Sai with Chicken" },
    description: { uz: "Tovuqli say", ru: "Сай с курицей", en: "Sai with chicken" },
    price: 42000, image: daapanjiImg,
  },
  {
    id: "u6", category: "uyghur",
    name: { uz: "Pelmeni uyg'urcha", ru: "Пельмени уйгурские", en: "Uyghur Pelmeni" },
    description: { uz: "Uyg'ur uslubida tayyorlangan pelmeni", ru: "Пельмени по-уйгурски", en: "Uyghur-style pelmeni" },
    price: 32000, image: pelmeniImg,
  },
  {
    id: "u7", category: "uyghur",
    name: { uz: "Qozon kabob uyg'urcha", ru: "Казан кабоб уйгурский", en: "Uyghur Kazan Kebab" },
    description: { uz: "Uyg'ur uslubida qozon kabob", ru: "Казан кабоб по-уйгурски", en: "Uyghur-style kazan kebab" },
    price: 50000, image: kawapImg,
  },
  {
    id: "u8", category: "uyghur",
    name: { uz: "Go'sht sabzavotli", ru: "Мясо с овощами", en: "Meat with Vegetables" },
    description: { uz: "Sabzavotlar bilan tayyorlangan go'sht", ru: "Мясо, приготовленное с овощами", en: "Meat cooked with vegetables" },
    price: 42000, image: daapanjiImg,
  },
  {
    id: "u9", category: "uyghur",
    name: { uz: "Go'sht qo'ziqorinli", ru: "Мясо с грибами", en: "Meat with Mushrooms" },
    description: { uz: "Qo'ziqorinlar bilan tayyorlangan go'sht", ru: "Мясо с грибами", en: "Meat prepared with mushrooms" },
    price: 45000, image: daapanjiImg,
  },
  {
    id: "u10", category: "uyghur",
    name: { uz: "Go'sht limonli", ru: "Мясо с лимоном", en: "Meat with Lemon" },
    description: { uz: "Limon bilan tayyorlangan go'sht", ru: "Мясо с лимоном", en: "Meat with lemon sauce" },
    price: 44000, image: daapanjiImg,
  },
  {
    id: "u11", category: "uyghur",
    name: { uz: "Go'sht uy uslubida", ru: "Мясо домашнее", en: "Homestyle Meat" },
    description: { uz: "Uy uslubida tayyorlangan go'sht", ru: "Мясо по-домашнему", en: "Homestyle prepared meat" },
    price: 42000, image: daapanjiImg,
  },

  // === SALATLAR ===
  {
    id: "s1", category: "salat",
    name: { uz: "Achichuk", ru: "Ачичук", en: "Achichuk" },
    description: { uz: "An'anaviy pomidor-piyozli salat", ru: "Традиционный салат из помидоров и лука", en: "Traditional tomato and onion salad" },
    price: 15000, image: saladImg,
  },
  {
    id: "s2", category: "salat",
    name: { uz: "Shakarob", ru: "Шакароб", en: "Shakarob" },
    description: { uz: "Pomidor va piyozli shakarob", ru: "Шакароб из помидоров и лука", en: "Shakarob with tomatoes and onions" },
    price: 15000, image: saladImg,
  },
  {
    id: "s3", category: "salat",
    name: { uz: "Narezka", ru: "Нарезка", en: "Platter" },
    description: { uz: "Go'sht va pishloqli narezka", ru: "Нарезка из мяса и сыра", en: "Meat and cheese platter" },
    price: 35000, image: saladImg,
  },
  {
    id: "s4", category: "salat",
    name: { uz: "Svejiy salat", ru: "Свежий салат", en: "Fresh Salad" },
    description: { uz: "Yangi sabzavotlardan salat", ru: "Салат из свежих овощей", en: "Fresh vegetable salad" },
    price: 18000, image: saladImg,
  },
  {
    id: "s5", category: "salat",
    name: { uz: "Suzma", ru: "Сузма", en: "Suzma" },
    description: { uz: "An'anaviy suzma", ru: "Традиционная сузьма", en: "Traditional strained yogurt" },
    price: 12000, image: saladImg,
  },
  {
    id: "s6", category: "salat",
    name: { uz: "Bahor salat", ru: "Весенний салат", en: "Spring Salad" },
    description: { uz: "Bahorgi yangi sabzavotli salat", ru: "Весенний салат из свежих овощей", en: "Spring salad with fresh vegetables" },
    price: 18000, image: saladImg,
  },
  {
    id: "s7", category: "salat",
    name: { uz: "Sezar", ru: "Цезарь", en: "Caesar" },
    description: { uz: "Klassik Sezar salati", ru: "Классический салат Цезарь", en: "Classic Caesar salad" },
    price: 28000, image: saladImg,
  },
  {
    id: "s8", category: "salat",
    name: { uz: "Olivye", ru: "Оливье", en: "Olivier" },
    description: { uz: "An'anaviy Olivye salati", ru: "Традиционный салат Оливье", en: "Traditional Olivier salad" },
    price: 22000, image: olivyeImg,
  },

  // === PARES TAOMLAR (GARNIR) ===
  {
    id: "g1", category: "garnir",
    name: { uz: "Guruch", ru: "Рис", en: "Rice" },
    description: { uz: "Bug'langan oq guruch", ru: "Отварной белый рис", en: "Steamed white rice" },
    price: 10000, image: riceImg,
  },
  {
    id: "g2", category: "garnir",
    name: { uz: "Grechixa", ru: "Гречка", en: "Buckwheat" },
    description: { uz: "Qaynatilgan grechixa", ru: "Отварная гречка", en: "Boiled buckwheat" },
    price: 10000, image: riceImg,
  },
  {
    id: "g3", category: "garnir",
    name: { uz: "Makaron", ru: "Макароны", en: "Pasta" },
    description: { uz: "Qaynatilgan makaron", ru: "Отварные макароны", en: "Boiled pasta" },
    price: 10000, image: riceImg,
  },
  {
    id: "g4", category: "garnir",
    name: { uz: "Pyure", ru: "Пюре", en: "Mashed Potatoes" },
    description: { uz: "Kartoshka pyuresi", ru: "Картофельное пюре", en: "Mashed potatoes" },
    price: 12000, image: riceImg,
  },
  {
    id: "g5", category: "garnir",
    name: { uz: "Fri", ru: "Фри", en: "French Fries" },
    description: { uz: "Qizarilgan kartoshka", ru: "Картофель фри", en: "French fries" },
    price: 15000, image: friesImg,
  },
];
